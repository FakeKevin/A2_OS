Assignment #2 - SYST 44288

Git bash was used to push the code to the repository.

Link to repository:

https://github.com/welshie1/a2

We included a picture of our git commands that were used, to show that we learned
how to use git bash.